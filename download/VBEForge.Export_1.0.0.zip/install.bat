@echo off
setlocal
cd /d "%~dp0"

rem ------------------------------------------------------------------
rem  This file must stay ASCII-only.
rem  cmd.exe re-reads the batch file while it runs, so switching the
rem  console code page (chcp) mid-file corrupts any multi-byte text
rem  that follows and splits lines into bogus commands.
rem  All Japanese messages are printed by the PowerShell script instead.
rem ------------------------------------------------------------------
chcp 65001 > nul

rem The distribution folder ships install.ps1; the dev tree has register.ps1.
set "PSFILE="
if exist "%~dp0install.ps1" set "PSFILE=%~dp0install.ps1"
if not defined PSFILE if exist "%~dp0register.ps1" set "PSFILE=%~dp0register.ps1"

if not defined PSFILE (
    echo ERROR: install.ps1 was not found next to this file.
    echo Keep install.bat and install.ps1 in the same folder.
    echo.
    pause
    exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%PSFILE%" -Interactive
exit /b %ERRORLEVEL%
