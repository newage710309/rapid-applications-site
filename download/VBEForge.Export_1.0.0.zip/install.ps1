﻿<#
.SYNOPSIS
    VBE Forge Export を VBE アドインとして現在のユーザーに登録します。

.DESCRIPTION
    管理者権限を必要としません。regasm は使わず、HKCU 配下へ次を書き込みます。

      HKCU:\Software\Classes\CLSID\{CLSID}            … COM クラス登録
      HKCU:\Software\Classes\{ProgID}                 … ProgID 登録
      HKCU:\Software\Microsoft\VBA\VBE\6.0\Addins     … 32bit VBE 用
      HKCU:\Software\Microsoft\VBA\VBE\6.0\Addins64   … 64bit VBE 用

    32bit / 64bit どちらの Excel からも読み込めるよう、CLSID は
    64bit ビュー (Software\Classes) と 32bit ビュー (Software\Classes\Wow6432Node)
    の両方へ書き込みます。

.PARAMETER DllPath
    VBEForge.Export.dll のパス。省略時は Release 出力 → Debug 出力の順で探します。

.PARAMETER LoadBehavior
    3 = Excel 起動時に自動ロード (既定)、0 = 手動ロード。

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File scripts\register.ps1

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File scripts\register.ps1 -DllPath "C:\Tools\VBEForge\VBEForge.Export.dll"
#>
[CmdletBinding()]
param(
    [string] $DllPath,
    [ValidateSet(0, 3)]
    [int] $LoadBehavior = 3,
    [switch] $Interactive
)

$ErrorActionPreference = 'Stop'

# install.bat から呼ばれたときの案内表示。
# バッチ側に日本語を置くと、cmd のコードページ切り替えで
# 行が壊れることがあるため、利用者向けの文言はすべてここで出す。
function Show-Banner {
    Write-Host '============================================================'
    Write-Host ' VBE Forge Export  インストール'
    Write-Host '============================================================'
    Write-Host ''
    Write-Host ' Excel をすべて終了してから続行してください。'
    Write-Host ' 管理者権限は不要です。'
    Write-Host ''
    Read-Host ' 続行するには Enter キーを押してください'
    Write-Host ''
}

# ---- アドインの識別情報 (src\VBEForge.Export\AddIn\ExportAddIn.cs と一致させること) ----
$ClassId      = '{51F7A628-0985-40B6-ACDD-42EE0A4C302A}'
$ProgId       = 'VBEForge.Export.ExportAddIn'
$ClassName    = 'VBEForge.Export.AddIn.ExportAddIn'
$FriendlyName = 'VBE Forge Export'
$Description  = 'VBAプロジェクト内のオブジェクトを一括エクスポートします。'
$AssemblyName = 'VBEForge.Export'

function Resolve-AddInDll {
    param([string] $Explicit)

    if ($Explicit) {
        if (-not (Test-Path -LiteralPath $Explicit)) {
            throw "指定された DLL が見つかりません: $Explicit"
        }
        return (Resolve-Path -LiteralPath $Explicit).Path
    }

    # 配布フォルダでは install.ps1 として DLL と同じ階層に置かれる。
    # 開発ツリーでは scripts\register.ps1 として 1 階層下に置かれる。
    # 両方の配置で動くように、まず自分と同じフォルダを見る。
    $root = Split-Path -Parent $PSScriptRoot
    $candidates = @(
        (Join-Path $PSScriptRoot 'VBEForge.Export.dll'),
        (Join-Path $root 'artifacts\VBEForge.Export\VBEForge.Export.dll'),
        (Join-Path $root 'src\VBEForge.Export\bin\Release\net48\VBEForge.Export.dll'),
        (Join-Path $root 'src\VBEForge.Export\bin\Debug\net48\VBEForge.Export.dll')
    )

    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate) {
            return (Resolve-Path -LiteralPath $candidate).Path
        }
    }

    throw "VBEForge.Export.dll が見つかりません。`n" +
          "このスクリプトと同じフォルダに VBEForge.Export.dll を置くか、`n" +
          "-DllPath でパスを指定してください。`n" +
          "探した場所:`n  " + ($candidates -join "`n  ")
}

function Set-RegistryValue {
    param(
        [string] $Path,
        [string] $Name,
        $Value,
        [string] $Type = 'String'
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -Path $Path -Force | Out-Null
    }

    New-ItemProperty -LiteralPath $Path -Name $Name -Value $Value -PropertyType $Type -Force | Out-Null
}

function Register-ComClass {
    param(
        [string] $ClassesRoot,
        [string] $Dll,
        [string] $Version
    )

    $clsidKey  = "$ClassesRoot\CLSID\$ClassId"
    $inprocKey = "$clsidKey\InprocServer32"

    Set-RegistryValue -Path $clsidKey  -Name '(default)' -Value $FriendlyName
    Set-RegistryValue -Path "$clsidKey\ProgId" -Name '(default)' -Value $ProgId

    # .NET Framework の標準ホスティング。mscoree.dll が CLR を立ち上げてクラスを生成する。
    Set-RegistryValue -Path $inprocKey -Name '(default)'     -Value 'mscoree.dll'
    Set-RegistryValue -Path $inprocKey -Name 'ThreadingModel' -Value 'Both'
    Set-RegistryValue -Path $inprocKey -Name 'Class'          -Value $ClassName
    Set-RegistryValue -Path $inprocKey -Name 'Assembly'       -Value "$AssemblyName, Version=$Version, Culture=neutral, PublicKeyToken=null"
    Set-RegistryValue -Path $inprocKey -Name 'RuntimeVersion' -Value 'v4.0.30319'
    Set-RegistryValue -Path $inprocKey -Name 'CodeBase'       -Value ([Uri]$Dll).AbsoluteUri

    # バージョン付きサブキー。regasm が作るものと同じ構造にしておく。
    $versionKey = "$inprocKey\$Version"
    Set-RegistryValue -Path $versionKey -Name 'Class'          -Value $ClassName
    Set-RegistryValue -Path $versionKey -Name 'Assembly'       -Value "$AssemblyName, Version=$Version, Culture=neutral, PublicKeyToken=null"
    Set-RegistryValue -Path $versionKey -Name 'RuntimeVersion' -Value 'v4.0.30319'
    Set-RegistryValue -Path $versionKey -Name 'CodeBase'       -Value ([Uri]$Dll).AbsoluteUri

    # ProgID → CLSID の対応。
    Set-RegistryValue -Path "$ClassesRoot\$ProgId" -Name '(default)' -Value $FriendlyName
    Set-RegistryValue -Path "$ClassesRoot\$ProgId\CLSID" -Name '(default)' -Value $ClassId
}

function Register-VbeAddIn {
    param([string] $AddinsKeyPath)

    $key = "$AddinsKeyPath\$ProgId"

    Set-RegistryValue -Path $key -Name 'FriendlyName'    -Value $FriendlyName
    Set-RegistryValue -Path $key -Name 'Description'     -Value $Description
    Set-RegistryValue -Path $key -Name 'LoadBehavior'    -Value $LoadBehavior -Type 'DWord'
    Set-RegistryValue -Path $key -Name 'CommandLineSafe' -Value 0             -Type 'DWord'
}

# ---- 実行 ----
$exitCode = 0

try {
    if ($Interactive) {
        Show-Banner
    }

    $dll = Resolve-AddInDll -Explicit $DllPath
    $assemblyVersion = [System.Reflection.AssemblyName]::GetAssemblyName($dll).Version.ToString()

    Write-Host "VBE Forge Export を登録します。"
    Write-Host "  DLL     : $dll"
    Write-Host "  Version : $assemblyVersion"
    Write-Host "  CLSID   : $ClassId"
    Write-Host ""

    # CLSID は 64bit ビューと 32bit ビューの両方へ書く。
    Register-ComClass -ClassesRoot 'HKCU:\Software\Classes' -Dll $dll -Version $assemblyVersion
    Register-ComClass -ClassesRoot 'HKCU:\Software\Classes\Wow6432Node' -Dll $dll -Version $assemblyVersion
    Write-Host "COM クラスを登録しました (32bit / 64bit 両ビュー)。"

    # VBE のアドイン一覧にも両方へ書く。
    Register-VbeAddIn -AddinsKeyPath 'HKCU:\Software\Microsoft\VBA\VBE\6.0\Addins'
    Register-VbeAddIn -AddinsKeyPath 'HKCU:\Software\Microsoft\VBA\VBE\6.0\Addins64'
    Write-Host "VBE アドインとして登録しました (Addins / Addins64)。"

    Write-Host ""
    Write-Host "------------------------------------------------------------"
    Write-Host " インストールが完了しました。" -ForegroundColor Green
    Write-Host ""
    Write-Host " Excel を起動し、Alt + F11 で VBE を開いてください。"
    Write-Host " [アドイン] メニューに [$FriendlyName] が追加されています。"
    Write-Host "------------------------------------------------------------"
}
catch {
    $exitCode = 1

    Write-Host ""
    Write-Host "------------------------------------------------------------"
    Write-Host " インストールに失敗しました。" -ForegroundColor Red
    Write-Host ""
    Write-Host $_.Exception.Message
    Write-Host "------------------------------------------------------------"
}
finally {
    if ($Interactive) {
        Write-Host ""
        Read-Host ' Enter キーを押すと閉じます'
    }
}

exit $exitCode
