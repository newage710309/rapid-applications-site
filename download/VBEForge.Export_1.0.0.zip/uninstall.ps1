﻿<#
.SYNOPSIS
    VBE Forge Export の登録を解除します。

.DESCRIPTION
    register.ps1 が書き込んだ HKCU 配下のキーをすべて削除します。
    管理者権限は不要です。存在しないキーは無視します。

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File scripts\unregister.ps1
#>
[CmdletBinding()]
param(
    [switch] $Interactive
)

$ErrorActionPreference = 'Stop'

# uninstall.bat から呼ばれたときの案内表示。
# バッチ側に日本語を置くと、cmd のコードページ切り替えで
# 行が壊れることがあるため、利用者向けの文言はすべてここで出す。
function Show-Banner {
    Write-Host '============================================================'
    Write-Host ' VBE Forge Export  アンインストール'
    Write-Host '============================================================'
    Write-Host ''
    Write-Host ' Excel をすべて終了してから続行してください。'
    Write-Host ' 管理者権限は不要です。'
    Write-Host ''
    Read-Host ' 続行するには Enter キーを押してください'
    Write-Host ''
}

# ---- register.ps1 と一致させること ----
$ClassId = '{51F7A628-0985-40B6-ACDD-42EE0A4C302A}'
$ProgId  = 'VBEForge.Export.ExportAddIn'

$keys = @(
    "HKCU:\Software\Classes\CLSID\$ClassId",
    "HKCU:\Software\Classes\Wow6432Node\CLSID\$ClassId",
    "HKCU:\Software\Classes\$ProgId",
    "HKCU:\Software\Classes\Wow6432Node\$ProgId",
    "HKCU:\Software\Microsoft\VBA\VBE\6.0\Addins\$ProgId",
    "HKCU:\Software\Microsoft\VBA\VBE\6.0\Addins64\$ProgId"
)

$exitCode = 0

try {
    if ($Interactive) {
        Show-Banner
    }

    $removed = 0

    foreach ($key in $keys) {
        if (Test-Path -LiteralPath $key) {
            Remove-Item -LiteralPath $key -Recurse -Force
            Write-Host "削除しました: $key"
            $removed++
        }
        else {
            Write-Verbose "存在しません: $key"
        }
    }

    Write-Host ""
    if ($removed -eq 0) {
        Write-Host "削除対象のキーはありませんでした。既に解除済みです。"
    }
    else {
        Write-Host "登録を解除しました ($removed 件)。"
    }

    Write-Host ""
    Write-Host "------------------------------------------------------------"
    Write-Host " アンインストールが完了しました。" -ForegroundColor Green
    Write-Host ""
    Write-Host " Excel を再起動すると [アドイン] メニューから消えます。"
    Write-Host " 展開したフォルダは手動で削除してください。"
    Write-Host ""
    Write-Host " ログと設定は次の場所に残ります。不要なら手動で削除してください。"
    Write-Host "   $env:LOCALAPPDATA\VBEForge"
    Write-Host "------------------------------------------------------------"
}
catch {
    $exitCode = 1

    Write-Host ""
    Write-Host "------------------------------------------------------------"
    Write-Host " アンインストールに失敗しました。" -ForegroundColor Red
    Write-Host ""
    Write-Host $_.Exception.Message
    Write-Host "------------------------------------------------------------"
}
finally {
    if ($Interactive) {
        Write-Host ""
        Read-Host ' Enter キーを押すと閉じます'
    }
}

exit $exitCode
