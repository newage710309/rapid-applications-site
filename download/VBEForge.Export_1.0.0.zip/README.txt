﻿# VBE Forge Export インストール手順

## 必要な環境

- Windows 10 / 11
- Microsoft Excel 2016 以降（Microsoft 365 を含む）／ 32bit・64bit どちらでも可
- .NET Framework 4.8（Windows 10 1903 以降には標準搭載）

## インストール

1. ZIP を任意のフォルダへ展開します。
   一度登録すると、そのフォルダの DLL を Excel が直接読み込みます。
   **登録後にフォルダを移動しないでください**（移動した場合は再登録が必要です）。

   例:

   ```text
   C:\Tools\VBEForge.Export\
   ```

2. Excel をすべて終了します。

3. 展開先フォルダの **`install.bat` をダブルクリック**します。

   コマンドを打つ必要はありません。
   黒い画面が開くので、案内に従って何かキーを押すと登録が始まります。
   「インストールが完了しました。」と出たら、キーを押して閉じてください。

   **管理者権限は不要です。** 登録先はすべて現在のユーザー（HKCU）配下です。

   > **ファイル名について**
   >
   > | 場所 | 登録 | 解除 |
   > | --- | --- | --- |
   > | 配布 ZIP を展開したフォルダ | **`install.bat`** | **`uninstall.bat`** |
   > | 同上（PowerShell から直接） | `install.ps1` | `uninstall.ps1` |
   > | 開発ツリー | `scripts\install.bat` / `scripts\register.ps1` | `scripts\uninstall.bat` / `scripts\unregister.ps1` |
   >
   > `.bat` は `.ps1` を呼び出しているだけで、処理内容は同じです。

   PowerShell から実行したい場合:

   ```powershell
   powershell -ExecutionPolicy Bypass -File .\install.ps1
   ```

   フルパスで実行しても構いません。その場合もスクリプトは
   **自分と同じフォルダにある `VBEForge.Export.dll`** を自動的に見つけます。

   ```powershell
   powershell -ExecutionPolicy Bypass -File C:\Tools\VBEForge.Export\install.ps1
   ```

   DLL を別の場所に置いている場合は明示できます。

   ```powershell
   powershell -ExecutionPolicy Bypass -File .\install.ps1 -DllPath C:\somewhere\VBEForge.Export.dll
   ```

4. Excel を起動し、VBE を開きます（Alt + F11）。

5. VBE のメニューに次が表示されます。

   ```text
   アドイン
     └ VBE Forge Export
   ```

## VBA プロジェクトへのアクセスを許可する

エクスポートには、Excel 側の信頼設定が必要です。

```text
[ファイル]
→ [オプション]
→ [トラストセンター]
→ [トラストセンターの設定]
→ [マクロの設定]
→ 「VBA プロジェクト オブジェクト モデルへのアクセスを信頼する」にチェック
```

設定後は Excel を再起動してください。

## 使い方

1. エクスポートしたいブックを開きます。
2. VBE（Alt + F11）で、プロジェクト エクスプローラーから対象プロジェクトを選択します。
3. `アドイン` → `VBE Forge Export` をクリックします。
4. 出力先フォルダとオプションを指定します。
   - 「コードが空のドキュメントモジュールを出力しない」を ON にすると、
     ThisWorkbook や Sheet1 など、コードが 1 行も無いものを除外します。
5. 完了ダイアログに件数が表示されます。

## アンインストール

**`uninstall.bat` をダブルクリック**します。

PowerShell から実行する場合:

```powershell
powershell -ExecutionPolicy Bypass -File .\uninstall.ps1
```

Excel を再起動すると、メニューから項目が消えます。

展開したフォルダは手動で削除してください。
ログと設定は次の場所に残るため、不要なら削除してください。

```text
%LOCALAPPDATA%\VBEForge\
```

## うまく動かないとき

### メニューに表示されない

- Excel を完全に終了してから登録し直してください。
- VBE の `アドイン` → `アドイン マネージャー` に `VBE Forge Export` があるか確認し、
  「ロード/アンロード」にチェックを入れてください。

### アドイン マネージャーにも表示されない

- `install.ps1` を実行したユーザーと Excel を実行しているユーザーが同じか確認してください。
- DLL のフォルダを移動していないか確認してください。移動した場合は再登録が必要です。

### ログの場所

```text
%LOCALAPPDATA%\VBEForge\Logs\VBEForge_yyyyMMdd.log
```

問題が起きたときは、このログに例外の詳細が記録されています。
