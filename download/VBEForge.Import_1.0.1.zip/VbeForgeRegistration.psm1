﻿<#
.SYNOPSIS
    VBE Forge シリーズ共通の VBE アドイン登録・解除処理。

.DESCRIPTION
    製品ごとの register.ps1 / unregister.ps1 から呼ばれる。
    製品固有の値（CLSID・ProgID など）は呼び出し側がハッシュテーブルで渡し、
    登録の手順そのものはここに一本化する。

    管理者権限を必要としない。regasm は使わず、HKCU 配下へ次を書き込む。

      HKCU:\Software\Classes\CLSID\{CLSID}            … COM クラス登録
      HKCU:\Software\Classes\{ProgID}                 … ProgID 登録
      HKCU:\Software\Microsoft\VBA\VBE\6.0\Addins     … 32bit VBE 用
      HKCU:\Software\Microsoft\VBA\VBE\6.0\Addins64   … 64bit VBE 用

    32bit / 64bit どちらの Excel からも読み込めるよう、CLSID は
    64bit ビュー (Software\Classes) と 32bit ビュー (Software\Classes\Wow6432Node)
    の両方へ書き込む。

    製品の定義（$Product）に必要なキー:
      Key          … 'Export' など。開発ツリーでの DLL 探索に使う
      Name         … 表示名（アドイン マネージャー・画面表示）
      Description  … アドイン マネージャーの説明
      AssemblyName … 'VBEForge.Export' など（拡張子なし）
      ClassName    … COM 公開クラスの完全名
      ClassId      … '{xxxxxxxx-...}' 形式の CLSID
      ProgId       … ProgID
#>

Set-StrictMode -Version 2.0

# ---------------------------------------------------------------------------
# 画面表示
# ---------------------------------------------------------------------------

# install.bat / uninstall.bat から呼ばれたときの案内表示。
# バッチ側に日本語を置くと、cmd のコードページ切り替えで
# 行が壊れることがあるため、利用者向けの文言はすべてここで出す。
function Show-VbeForgeBanner {
    param([string] $Title)

    Write-Host '============================================================'
    Write-Host " $Title"
    Write-Host '============================================================'
    Write-Host ''
    Write-Host ' Excel をすべて終了してから続行してください。'
    Write-Host ' 管理者権限は不要です。'
    Write-Host ''
    [void](Read-Host ' 続行するには Enter キーを押してください')
    Write-Host ''
}

function Wait-VbeForgeClose {
    Write-Host ''
    [void](Read-Host ' Enter キーを押すと閉じます')
}

function Write-VbeForgeRule {
    Write-Host '------------------------------------------------------------'
}

# ---------------------------------------------------------------------------
# レジストリ
# ---------------------------------------------------------------------------

function Set-VbeForgeRegistryValue {
    param(
        [string] $Path,
        [string] $Name,
        $Value,
        [string] $Type = 'String'
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        [void](New-Item -Path $Path -Force)
    }

    [void](New-ItemProperty -LiteralPath $Path -Name $Name -Value $Value -PropertyType $Type -Force)
}

function Resolve-VbeForgeDll {
    param(
        [hashtable] $Product,
        [string] $ScriptRoot,
        [string] $Explicit
    )

    if ($Explicit) {
        if (-not (Test-Path -LiteralPath $Explicit)) {
            throw "指定された DLL が見つかりません: $Explicit"
        }
        return (Resolve-Path -LiteralPath $Explicit).Path
    }

    $dllName = "$($Product.AssemblyName).dll"

    # 配布フォルダでは install.ps1 として DLL と同じ階層に置かれる。
    # 開発ツリーでは scripts\<製品>\register.ps1 として 2 階層下に置かれる。
    $repoRoot = Split-Path -Parent (Split-Path -Parent $ScriptRoot)
    $project  = "VBEForge.$($Product.Key)"

    $candidates = @(
        (Join-Path $ScriptRoot $dllName),
        (Join-Path $repoRoot "artifacts\$project\$dllName"),
        (Join-Path $repoRoot "src\$project\bin\Release\net48\$dllName"),
        (Join-Path $repoRoot "src\$project\bin\Debug\net48\$dllName")
    )

    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate) {
            return (Resolve-Path -LiteralPath $candidate).Path
        }
    }

    throw "$dllName が見つかりません。`n" +
          "このスクリプトと同じフォルダに $dllName を置くか、`n" +
          "-DllPath でパスを指定してください。`n" +
          "探した場所:`n  " + ($candidates -join "`n  ")
}

function Register-VbeForgeComClass {
    param(
        [hashtable] $Product,
        [string] $ClassesRoot,
        [string] $Dll,
        [string] $Version
    )

    $clsidKey   = "$ClassesRoot\CLSID\$($Product.ClassId)"
    $inprocKey  = "$clsidKey\InprocServer32"
    $assembly   = "$($Product.AssemblyName), Version=$Version, Culture=neutral, PublicKeyToken=null"
    $codeBase   = ([Uri]$Dll).AbsoluteUri

    Set-VbeForgeRegistryValue -Path $clsidKey -Name '(default)' -Value $Product.Name
    Set-VbeForgeRegistryValue -Path "$clsidKey\ProgId" -Name '(default)' -Value $Product.ProgId

    # .NET Framework の標準ホスティング。mscoree.dll が CLR を立ち上げてクラスを生成する。
    Set-VbeForgeRegistryValue -Path $inprocKey -Name '(default)'      -Value 'mscoree.dll'
    Set-VbeForgeRegistryValue -Path $inprocKey -Name 'ThreadingModel' -Value 'Both'
    Set-VbeForgeRegistryValue -Path $inprocKey -Name 'Class'          -Value $Product.ClassName
    Set-VbeForgeRegistryValue -Path $inprocKey -Name 'Assembly'       -Value $assembly
    Set-VbeForgeRegistryValue -Path $inprocKey -Name 'RuntimeVersion' -Value 'v4.0.30319'
    Set-VbeForgeRegistryValue -Path $inprocKey -Name 'CodeBase'       -Value $codeBase

    # バージョン付きサブキー。regasm が作るものと同じ構造にしておく。
    $versionKey = "$inprocKey\$Version"
    Set-VbeForgeRegistryValue -Path $versionKey -Name 'Class'          -Value $Product.ClassName
    Set-VbeForgeRegistryValue -Path $versionKey -Name 'Assembly'       -Value $assembly
    Set-VbeForgeRegistryValue -Path $versionKey -Name 'RuntimeVersion' -Value 'v4.0.30319'
    Set-VbeForgeRegistryValue -Path $versionKey -Name 'CodeBase'       -Value $codeBase

    # ProgID → CLSID の対応。
    Set-VbeForgeRegistryValue -Path "$ClassesRoot\$($Product.ProgId)" -Name '(default)' -Value $Product.Name
    Set-VbeForgeRegistryValue -Path "$ClassesRoot\$($Product.ProgId)\CLSID" -Name '(default)' -Value $Product.ClassId
}

function Register-VbeForgeVbeEntry {
    param(
        [hashtable] $Product,
        [string] $AddinsKeyPath,
        [int] $LoadBehavior
    )

    $key = "$AddinsKeyPath\$($Product.ProgId)"

    Set-VbeForgeRegistryValue -Path $key -Name 'FriendlyName'    -Value $Product.Name
    Set-VbeForgeRegistryValue -Path $key -Name 'Description'     -Value $Product.Description
    Set-VbeForgeRegistryValue -Path $key -Name 'LoadBehavior'    -Value $LoadBehavior -Type 'DWord'
    Set-VbeForgeRegistryValue -Path $key -Name 'CommandLineSafe' -Value 0             -Type 'DWord'
}

function Get-VbeForgeRegistryKeys {
    param([hashtable] $Product)

    return @(
        "HKCU:\Software\Classes\CLSID\$($Product.ClassId)",
        "HKCU:\Software\Classes\Wow6432Node\CLSID\$($Product.ClassId)",
        "HKCU:\Software\Classes\$($Product.ProgId)",
        "HKCU:\Software\Classes\Wow6432Node\$($Product.ProgId)",
        "HKCU:\Software\Microsoft\VBA\VBE\6.0\Addins\$($Product.ProgId)",
        "HKCU:\Software\Microsoft\VBA\VBE\6.0\Addins64\$($Product.ProgId)"
    )
}

# ---------------------------------------------------------------------------
# 公開関数
# ---------------------------------------------------------------------------

<#
.SYNOPSIS
    VBE アドインを現在のユーザーに登録する。
.OUTPUTS
    終了コード（成功 0 / 失敗 1）。
#>
function Register-VbeForgeAddIn {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)] [hashtable] $Product,
        [Parameter(Mandatory)] [string] $ScriptRoot,
        [string] $DllPath,
        [int] $LoadBehavior = 3,
        [switch] $Interactive
    )

    $ErrorActionPreference = 'Stop'
    $exitCode = 0

    try {
        if ($Interactive) {
            Show-VbeForgeBanner -Title "$($Product.Name)  インストール"
        }

        $dll = Resolve-VbeForgeDll -Product $Product -ScriptRoot $ScriptRoot -Explicit $DllPath
        $version = [System.Reflection.AssemblyName]::GetAssemblyName($dll).Version.ToString()

        Write-Host "$($Product.Name) を登録します。"
        Write-Host "  DLL     : $dll"
        Write-Host "  Version : $version"
        Write-Host "  CLSID   : $($Product.ClassId)"
        Write-Host ''

        # CLSID は 64bit ビューと 32bit ビューの両方へ書く。
        Register-VbeForgeComClass -Product $Product -ClassesRoot 'HKCU:\Software\Classes' -Dll $dll -Version $version
        Register-VbeForgeComClass -Product $Product -ClassesRoot 'HKCU:\Software\Classes\Wow6432Node' -Dll $dll -Version $version
        Write-Host 'COM クラスを登録しました (32bit / 64bit 両ビュー)。'

        # VBE のアドイン一覧にも両方へ書く。
        Register-VbeForgeVbeEntry -Product $Product -AddinsKeyPath 'HKCU:\Software\Microsoft\VBA\VBE\6.0\Addins' -LoadBehavior $LoadBehavior
        Register-VbeForgeVbeEntry -Product $Product -AddinsKeyPath 'HKCU:\Software\Microsoft\VBA\VBE\6.0\Addins64' -LoadBehavior $LoadBehavior
        Write-Host 'VBE アドインとして登録しました (Addins / Addins64)。'

        Write-Host ''
        Write-VbeForgeRule
        Write-Host ' インストールが完了しました。' -ForegroundColor Green
        Write-Host ''
        Write-Host ' Excel を起動し、Alt + F11 で VBE を開いてください。'
        Write-Host " [アドイン] メニューに [$($Product.Name)] が追加されています。"
        Write-VbeForgeRule
    }
    catch {
        $exitCode = 1

        Write-Host ''
        Write-VbeForgeRule
        Write-Host ' インストールに失敗しました。' -ForegroundColor Red
        Write-Host ''
        Write-Host $_.Exception.Message
        Write-VbeForgeRule
    }
    finally {
        if ($Interactive) {
            Wait-VbeForgeClose
        }
    }

    return $exitCode
}

<#
.SYNOPSIS
    VBE アドインの登録を解除する。
.OUTPUTS
    終了コード（成功 0 / 失敗 1）。
#>
function Unregister-VbeForgeAddIn {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)] [hashtable] $Product,
        [switch] $Interactive
    )

    $ErrorActionPreference = 'Stop'
    $exitCode = 0

    try {
        if ($Interactive) {
            Show-VbeForgeBanner -Title "$($Product.Name)  アンインストール"
        }

        $removed = 0

        foreach ($key in (Get-VbeForgeRegistryKeys -Product $Product)) {
            if (Test-Path -LiteralPath $key) {
                Remove-Item -LiteralPath $key -Recurse -Force
                Write-Host "削除しました: $key"
                $removed++
            }
            else {
                Write-Verbose "存在しません: $key"
            }
        }

        Write-Host ''
        if ($removed -eq 0) {
            Write-Host '削除対象のキーはありませんでした。既に解除済みです。'
        }
        else {
            Write-Host "登録を解除しました ($removed 件)。"
        }

        Write-Host ''
        Write-VbeForgeRule
        Write-Host ' アンインストールが完了しました。' -ForegroundColor Green
        Write-Host ''
        Write-Host ' Excel を再起動すると [アドイン] メニューから消えます。'
        Write-Host ' 展開したフォルダは手動で削除してください。'
        Write-Host ''
        Write-Host ' ログと設定は次の場所に残ります。不要なら手動で削除してください。'
        Write-Host "   $env:LOCALAPPDATA\VBEForge"
        Write-VbeForgeRule
    }
    catch {
        $exitCode = 1

        Write-Host ''
        Write-VbeForgeRule
        Write-Host ' アンインストールに失敗しました。' -ForegroundColor Red
        Write-Host ''
        Write-Host $_.Exception.Message
        Write-VbeForgeRule
    }
    finally {
        if ($Interactive) {
            Wait-VbeForgeClose
        }
    }

    return $exitCode
}

Export-ModuleMember -Function Register-VbeForgeAddIn, Unregister-VbeForgeAddIn
