﻿<#
.SYNOPSIS
    VBE Forge Import を VBE アドインとして現在のユーザーに登録します。

.DESCRIPTION
    管理者権限を必要としません。登録処理の本体は
    VbeForgeRegistration.psm1（シリーズ共通）にあり、ここでは製品の識別情報だけを持ちます。

.PARAMETER DllPath
    VBEForge.Import.dll のパス。省略時は同じフォルダ → artifacts → Release → Debug の順で探します。

.PARAMETER LoadBehavior
    3 = Excel 起動時に自動ロード (既定)、0 = 手動ロード。

.PARAMETER Interactive
    install.bat から呼ばれたときに指定します。開始前と終了時に Enter 待ちを入れます。

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File scripts\Import\register.ps1
#>
[CmdletBinding()]
param(
    [string] $DllPath,
    [ValidateSet(0, 3)]
    [int] $LoadBehavior = 3,
    [switch] $Interactive
)

# ---- 製品の識別情報 (src\VBEForge.Import\AddIn\ImportAddIn.cs と一致させること) ----
$Product = @{
    Key          = 'Import'
    Name         = 'VBE Forge Import'
    Description  = 'フォルダ内のVBAソースファイルをVBAプロジェクトへ一括インポートします。'
    AssemblyName = 'VBEForge.Import'
    ClassName    = 'VBEForge.Import.AddIn.ImportAddIn'
    ClassId      = '{5EF6B885-6732-41A5-8D08-2A2085A21A44}'
    ProgId       = 'VBEForge.Import.ImportAddIn'
}

# 配布フォルダでは同じ階層、開発ツリーでは scripts\common にある。
$module = @(
    (Join-Path $PSScriptRoot 'VbeForgeRegistration.psm1'),
    (Join-Path $PSScriptRoot '..\common\VbeForgeRegistration.psm1')
) | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1

if (-not $module) {
    Write-Host 'VbeForgeRegistration.psm1 が見つかりません。配布ファイル一式を同じフォルダに置いてください。' -ForegroundColor Red
    if ($Interactive) { [void](Read-Host ' Enter キーを押すと閉じます') }
    exit 1
}

Import-Module $module -Force
exit (Register-VbeForgeAddIn -Product $Product -ScriptRoot $PSScriptRoot -DllPath $DllPath -LoadBehavior $LoadBehavior -Interactive:$Interactive)
