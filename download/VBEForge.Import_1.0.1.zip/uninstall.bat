@echo off
setlocal
cd /d "%~dp0"

rem ------------------------------------------------------------------
rem  This file must stay ASCII-only.
rem  cmd.exe re-reads the batch file while it runs, so switching the
rem  console code page (chcp) mid-file corrupts any multi-byte text
rem  that follows and splits lines into bogus commands.
rem  All Japanese messages are printed by the PowerShell script instead.
rem ------------------------------------------------------------------
chcp 65001 > nul

rem This launcher is shared by every VBE Forge product.
rem build-release.ps1 copies it next to the product's uninstall.ps1.
set "PSFILE=%~dp0uninstall.ps1"

if not exist "%PSFILE%" (
    echo ERROR: uninstall.ps1 was not found next to this file.
    echo Keep uninstall.bat and uninstall.ps1 in the same folder.
    echo.
    pause
    exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%PSFILE%" -Interactive
exit /b %ERRORLEVEL%
