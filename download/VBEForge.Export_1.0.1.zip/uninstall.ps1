﻿<#
.SYNOPSIS
    VBE Forge Export の登録を解除します。

.DESCRIPTION
    register.ps1 が書き込んだ HKCU 配下のキーをすべて削除します。
    管理者権限は不要です。存在しないキーは無視します。

.PARAMETER Interactive
    uninstall.bat から呼ばれたときに指定します。開始前と終了時に Enter 待ちを入れます。

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File scripts\Export\unregister.ps1
#>
[CmdletBinding()]
param(
    [switch] $Interactive
)

# ---- register.ps1 と一致させること ----
$Product = @{
    Key     = 'Export'
    Name    = 'VBE Forge Export'
    ClassId = '{51F7A628-0985-40B6-ACDD-42EE0A4C302A}'
    ProgId  = 'VBEForge.Export.ExportAddIn'
}

# 配布フォルダでは同じ階層、開発ツリーでは scripts\common にある。
$module = @(
    (Join-Path $PSScriptRoot 'VbeForgeRegistration.psm1'),
    (Join-Path $PSScriptRoot '..\common\VbeForgeRegistration.psm1')
) | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1

if (-not $module) {
    Write-Host 'VbeForgeRegistration.psm1 が見つかりません。配布ファイル一式を同じフォルダに置いてください。' -ForegroundColor Red
    if ($Interactive) { [void](Read-Host ' Enter キーを押すと閉じます') }
    exit 1
}

Import-Module $module -Force
exit (Unregister-VbeForgeAddIn -Product $Product -Interactive:$Interactive)
