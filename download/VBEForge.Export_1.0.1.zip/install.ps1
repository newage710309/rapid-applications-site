﻿<#
.SYNOPSIS
    VBE Forge Export を VBE アドインとして現在のユーザーに登録します。

.DESCRIPTION
    管理者権限を必要としません。登録処理の本体は
    VbeForgeRegistration.psm1（シリーズ共通）にあり、ここでは製品の識別情報だけを持ちます。

.PARAMETER DllPath
    VBEForge.Export.dll のパス。省略時は同じフォルダ → artifacts → Release → Debug の順で探します。

.PARAMETER LoadBehavior
    3 = Excel 起動時に自動ロード (既定)、0 = 手動ロード。

.PARAMETER Interactive
    install.bat から呼ばれたときに指定します。開始前と終了時に Enter 待ちを入れます。

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File scripts\Export\register.ps1
#>
[CmdletBinding()]
param(
    [string] $DllPath,
    [ValidateSet(0, 3)]
    [int] $LoadBehavior = 3,
    [switch] $Interactive
)

# ---- 製品の識別情報 (src\VBEForge.Export\AddIn\ExportAddIn.cs と一致させること) ----
$Product = @{
    Key          = 'Export'
    Name         = 'VBE Forge Export'
    Description  = 'VBAプロジェクト内のオブジェクトを一括エクスポートします。'
    AssemblyName = 'VBEForge.Export'
    ClassName    = 'VBEForge.Export.AddIn.ExportAddIn'
    ClassId      = '{51F7A628-0985-40B6-ACDD-42EE0A4C302A}'
    ProgId       = 'VBEForge.Export.ExportAddIn'
}

# 配布フォルダでは同じ階層、開発ツリーでは scripts\common にある。
$module = @(
    (Join-Path $PSScriptRoot 'VbeForgeRegistration.psm1'),
    (Join-Path $PSScriptRoot '..\common\VbeForgeRegistration.psm1')
) | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1

if (-not $module) {
    Write-Host 'VbeForgeRegistration.psm1 が見つかりません。配布ファイル一式を同じフォルダに置いてください。' -ForegroundColor Red
    if ($Interactive) { [void](Read-Host ' Enter キーを押すと閉じます') }
    exit 1
}

Import-Module $module -Force
exit (Register-VbeForgeAddIn -Product $Product -ScriptRoot $PSScriptRoot -DllPath $DllPath -LoadBehavior $LoadBehavior -Interactive:$Interactive)
